/* 20220665 YoungJun Yu */

#include <stdio.h>
#include "cachelab.h"
#include <getopt.h>
#include <stdlib.h>
#include <unistd.h>

typedef struct {
    int valid;
    int tag;
    int lru;
}line;

typedef struct {
    line* lines;
}set;

typedef struct {
    set* sets;
}caches;

void simulation(int address);

caches cache;
int hit_count = 0, miss_count = 0, eviction_count = 0;
int s, E, b;

int main(int argc, char* argv[])
{
    FILE* t;

    int opt;    

    /*s, E, b �Է¹ޱ�*/
    while ((opt = getopt(argc, argv, "s:E:b:t:")) != -1) {
        switch (opt) {
        case 's':
            s = atoi(optarg);
            break;
        case 'E':
            E = atoi(optarg);
            break;
        case 'b':
            b = atoi(optarg);
            break;
        case 't':
            t = fopen(optarg, "r");
            break;
        case '?':
            return 1;
        default:
            break;
        }
    }

    /*cache ���� �����Ҵ�*/
    cache.sets = malloc(sizeof(set) * (1 << s));
    for (int i = 0; i < 1 << s; i++) {
        cache.sets[i].lines = malloc(sizeof(line) * E);

        for (int j = 0; j < E; j++) {
            cache.sets[i].lines[j].valid = 0;
            cache.sets[i].lines[j].tag = 0;
            cache.sets[i].lines[j].lru = 0;
        }
    }

    /*cache access ����*/
    char operation;
    int address;
    int size;
    while ((fscanf(t, " %c %x,%d", &operation, &address, &size)) != EOF) {
        if (operation == 'I') {
            continue;
        }
        else if(operation == 'M') {
            simulation(address);
            simulation(address);
        }
        else {
            simulation(address);
        }
    }

    /*�����Ҵ� ����*/
    for (int i = 0; i < 1 << s; i++) {
        free(cache.sets[i].lines);
    }
    free(cache.sets);
    fclose(t);

    printSummary(hit_count, miss_count, eviction_count);
    return 0;
}

void simulation(int address) {
    int tag = address >> (s + b); /*address�� tag �κ�*/
    int set_idx = (~(tag << (s + b)) & address) >> b; /*address�� set_idx �κ�, tag�κ��� ���� �� b��ŭ right shift ���ش�.*/

    for (int i = 0; i < E; i++) {
        if (cache.sets[set_idx].lines[i].valid && tag == cache.sets[set_idx].lines[i].tag) {
            hit_count++;
            cache.sets[set_idx].lines[i].lru = 1;
            for (int j = 0; j < E; j++) {
                if (cache.sets[set_idx].lines[j].valid == 1 && i != j) {
                    cache.sets[set_idx].lines[j].lru++;
                }
            }
            return;
        }
    }

    int is_set_full = 1; /*set�� �� á���� Ȯ���ϱ� ���� ����*/
    for (int i = 0; i < E; i++) {
        if (!cache.sets[set_idx].lines[i].valid) {
            is_set_full = 0;
            break;
        }
    }

    /*set�� �� ���� ���� ���*/
    if (!is_set_full) {
        miss_count++;

        for (int i = 0; i < E; i++) {
            if (!cache.sets[set_idx].lines[i].valid) {
                cache.sets[set_idx].lines[i].valid = 1;
                cache.sets[set_idx].lines[i].tag = tag;
                cache.sets[set_idx].lines[i].lru = 1;
                for (int j = 0; j < E; j++) {
                    if (cache.sets[set_idx].lines[j].valid == 1 && i != j) {
                        cache.sets[set_idx].lines[j].lru++;
                    }
                }
                break;
            }
        }
    }
    /*set�� �� �� ���*/
    else {
        miss_count++;
        eviction_count++;

        line *lru_line = &cache.sets[set_idx].lines[0];
        for (int i = 0; i < E; i++) {
            if (cache.sets[set_idx].lines[i].lru > lru_line->lru) {
                lru_line = &cache.sets[set_idx].lines[i];
            }
        }
        lru_line->tag = tag;    
        lru_line->lru = 0;
        for (int j = 0; j < E; j++) {
            if (cache.sets[set_idx].lines[j].valid == 1) {
                cache.sets[set_idx].lines[j].lru++;
            }
        }
    }

    return;
}
